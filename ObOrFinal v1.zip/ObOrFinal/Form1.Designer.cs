﻿namespace ObOrFinal
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nascarbutton = new System.Windows.Forms.Button();
            this.footballbutton = new System.Windows.Forms.Button();
            this.baseballbutton = new System.Windows.Forms.Button();
            this.rawdatabutton = new System.Windows.Forms.Button();
            this.pastfilebutton = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Programtitle = new System.Windows.Forms.Label();
            this.inputbox = new System.Windows.Forms.TextBox();
            this.pastdatabox = new System.Windows.Forms.TextBox();
            this.curdatabox = new System.Windows.Forms.TextBox();
            this.Changes = new System.Windows.Forms.TextBox();
            this.textboxlabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nascarbutton
            // 
            this.nascarbutton.Location = new System.Drawing.Point(55, 157);
            this.nascarbutton.Name = "nascarbutton";
            this.nascarbutton.Size = new System.Drawing.Size(135, 80);
            this.nascarbutton.TabIndex = 0;
            this.nascarbutton.Text = "NASCAR";
            this.nascarbutton.UseVisualStyleBackColor = true;
            this.nascarbutton.Click += new System.EventHandler(this.nascarbutton_Click);
            // 
            // footballbutton
            // 
            this.footballbutton.Location = new System.Drawing.Point(55, 254);
            this.footballbutton.Name = "footballbutton";
            this.footballbutton.Size = new System.Drawing.Size(135, 80);
            this.footballbutton.TabIndex = 1;
            this.footballbutton.Text = "Football";
            this.footballbutton.UseVisualStyleBackColor = true;
            this.footballbutton.Click += new System.EventHandler(this.footballbutton_Click);
            // 
            // baseballbutton
            // 
            this.baseballbutton.Location = new System.Drawing.Point(55, 358);
            this.baseballbutton.Name = "baseballbutton";
            this.baseballbutton.Size = new System.Drawing.Size(135, 80);
            this.baseballbutton.TabIndex = 2;
            this.baseballbutton.Text = "Baseball";
            this.baseballbutton.UseVisualStyleBackColor = true;
            this.baseballbutton.Click += new System.EventHandler(this.baseballbutton_Click);
            // 
            // rawdatabutton
            // 
            this.rawdatabutton.Location = new System.Drawing.Point(285, 407);
            this.rawdatabutton.Name = "rawdatabutton";
            this.rawdatabutton.Size = new System.Drawing.Size(135, 31);
            this.rawdatabutton.TabIndex = 3;
            this.rawdatabutton.Text = "See Raw Data";
            this.rawdatabutton.UseVisualStyleBackColor = true;
            // 
            // pastfilebutton
            // 
            this.pastfilebutton.Location = new System.Drawing.Point(474, 407);
            this.pastfilebutton.Name = "pastfilebutton";
            this.pastfilebutton.Size = new System.Drawing.Size(135, 31);
            this.pastfilebutton.TabIndex = 4;
            this.pastfilebutton.Text = "Print Past File";
            this.pastfilebutton.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(285, 358);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(113, 24);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Programtitle
            // 
            this.Programtitle.AutoSize = true;
            this.Programtitle.Location = new System.Drawing.Point(51, 23);
            this.Programtitle.Name = "Programtitle";
            this.Programtitle.Size = new System.Drawing.Size(210, 20);
            this.Programtitle.TabIndex = 6;
            this.Programtitle.Text = "I Hate This Guy Stat Tracker";
            this.Programtitle.Click += new System.EventHandler(this.label1_Click);
            // 
            // inputbox
            // 
            this.inputbox.Location = new System.Drawing.Point(55, 81);
            this.inputbox.Name = "inputbox";
            this.inputbox.Size = new System.Drawing.Size(280, 26);
            this.inputbox.TabIndex = 7;
            this.inputbox.TextChanged += new System.EventHandler(this.inputbox_TextChanged);
            // 
            // pastdatabox
            // 
            this.pastdatabox.BackColor = System.Drawing.SystemColors.MenuText;
            this.pastdatabox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.pastdatabox.Location = new System.Drawing.Point(437, 81);
            this.pastdatabox.Multiline = true;
            this.pastdatabox.Name = "pastdatabox";
            this.pastdatabox.ReadOnly = true;
            this.pastdatabox.Size = new System.Drawing.Size(331, 48);
            this.pastdatabox.TabIndex = 8;
            this.pastdatabox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // curdatabox
            // 
            this.curdatabox.BackColor = System.Drawing.SystemColors.MenuText;
            this.curdatabox.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.curdatabox.Location = new System.Drawing.Point(437, 189);
            this.curdatabox.Multiline = true;
            this.curdatabox.Name = "curdatabox";
            this.curdatabox.ReadOnly = true;
            this.curdatabox.Size = new System.Drawing.Size(331, 48);
            this.curdatabox.TabIndex = 9;
            // 
            // Changes
            // 
            this.Changes.BackColor = System.Drawing.SystemColors.MenuText;
            this.Changes.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Changes.Location = new System.Drawing.Point(437, 281);
            this.Changes.Multiline = true;
            this.Changes.Name = "Changes";
            this.Changes.ReadOnly = true;
            this.Changes.Size = new System.Drawing.Size(331, 48);
            this.Changes.TabIndex = 10;
            // 
            // textboxlabel
            // 
            this.textboxlabel.AutoSize = true;
            this.textboxlabel.Location = new System.Drawing.Point(54, 58);
            this.textboxlabel.Name = "textboxlabel";
            this.textboxlabel.Size = new System.Drawing.Size(136, 20);
            this.textboxlabel.TabIndex = 11;
            this.textboxlabel.Text = "Input player name";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textboxlabel);
            this.Controls.Add(this.Changes);
            this.Controls.Add(this.curdatabox);
            this.Controls.Add(this.pastdatabox);
            this.Controls.Add(this.inputbox);
            this.Controls.Add(this.Programtitle);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.pastfilebutton);
            this.Controls.Add(this.rawdatabutton);
            this.Controls.Add(this.baseballbutton);
            this.Controls.Add(this.footballbutton);
            this.Controls.Add(this.nascarbutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button nascarbutton;
        private System.Windows.Forms.Button footballbutton;
        private System.Windows.Forms.Button baseballbutton;
        private System.Windows.Forms.Button rawdatabutton;
        private System.Windows.Forms.Button pastfilebutton;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label Programtitle;
        private System.Windows.Forms.TextBox inputbox;
        private System.Windows.Forms.TextBox pastdatabox;
        private System.Windows.Forms.TextBox curdatabox;
        private System.Windows.Forms.TextBox Changes;
        private System.Windows.Forms.Label textboxlabel;
    }
}

