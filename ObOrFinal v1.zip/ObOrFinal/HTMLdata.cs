﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using HtmlAgilityPack;

namespace ObOrFinal
{
    internal class HTMLdata
    {
        string nascarraw;
        string baseballraw;
        string footballraw;
        #region call methods
        
        public static async Task<string> nascarfind(string hatedriver)
        {
            string url = "https://www.driveraverages.com/";
            string pulledtext = await CallURL(url);
            Console.WriteLine("url called");
            return pulledtext;
        }

      
        public static async Task<string> CallURL(string url)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12; // Use Tls12
                    client.DefaultRequestHeaders.Accept.Clear();
                    return await client.GetStringAsync(url);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in CallURL: " + ex.Message);
                return " ";
            }
        }
        public static string nascarExtractTextFromHtml(string html, string hatedriver)
        {
            if (html == null)
            {
                return "";
            }
            string plainText = Regex.Replace(html, "\r?\n|<[^>]+?>|/[^/]+?/|{[^}]+?}", " ");
            plainText = System.Net.WebUtility.HtmlDecode(plainText).Trim();
            int index = plainText.IndexOf(hatedriver, StringComparison.OrdinalIgnoreCase);
            if (index >= 0)
            {
                plainText = plainText.Substring(index).Trim();
            }
            int percentIndex = plainText.IndexOf('%');
            if (percentIndex >= 0)
            {
                plainText = plainText.Substring(0, percentIndex).Trim();
            }

            return plainText;
        }
        
        #endregion


    }
}
